====================
salt.modules.beacons
====================

.. automodule:: salt.modules.beacons
    :members:
