salt.modules.kubeadm module
===========================

.. automodule:: salt.modules.kubeadm
    :members:
