=============================
salt.modules.azurearm_compute
=============================

.. automodule:: salt.modules.azurearm_compute
    :members: