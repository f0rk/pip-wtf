=====================
salt.modules.glanceng
=====================

.. automodule:: salt.modules.glanceng
    :members:
