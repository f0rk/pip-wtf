salt.modules.freezer module
===========================

.. automodule:: salt.modules.freezer
    :members:
    :undoc-members:
