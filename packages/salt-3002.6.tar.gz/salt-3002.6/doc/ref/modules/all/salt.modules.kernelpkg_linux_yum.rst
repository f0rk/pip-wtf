================================
salt.modules.kernelpkg_linux_yum
================================

.. automodule:: salt.modules.kernelpkg_linux_yum
    :members: