====================
salt.modules.devinfo
====================

.. automodule:: salt.modules.devinfo
    :members:
