===================
salt.modules.apkpkg
===================

.. automodule:: salt.modules.apkpkg
    :members:
    :undoc-members:
