salt.modules.idem module
========================

.. automodule:: salt.modules.idem
    :members:
