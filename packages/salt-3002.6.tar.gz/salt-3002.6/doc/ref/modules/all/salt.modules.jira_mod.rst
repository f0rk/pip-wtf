============================
salt.modules.jira_mod module
============================

.. automodule:: salt.modules.jira_mod
    :members:

