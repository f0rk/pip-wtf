salt.modules.boto_ssm module
============================

.. automodule:: salt.modules.boto_ssm
    :members:
    :undoc-members:
