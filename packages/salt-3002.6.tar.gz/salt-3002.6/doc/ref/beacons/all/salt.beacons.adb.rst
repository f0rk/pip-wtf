salt.beacons.adb module
=======================

.. automodule:: salt.beacons.adb
    :members:
