===============
salt.grains.lvm
===============

.. automodule:: salt.grains.lvm
    :members:
