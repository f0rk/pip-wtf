# Licensed under the Apache License: http://www.apache.org/licenses/LICENSE-2.0
# For details: https://github.com/nedbat/coveragepy/blob/master/NOTICE.txt

# Module-level docstrings are counted differently in different versions of Python,
# so don't add one here.
# pylint: disable=missing-module-docstring

# covmodzip.py: for putting into a zip file.
j = 1
j += 1
