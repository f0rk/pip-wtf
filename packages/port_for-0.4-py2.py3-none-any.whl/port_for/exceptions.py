# -*- coding: utf-8 -*-
class PortForException(Exception):
    pass