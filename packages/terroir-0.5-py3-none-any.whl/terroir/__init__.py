# Copyright 2019-2021, Ryan P. Kelly.

__version__ = "0.5"
