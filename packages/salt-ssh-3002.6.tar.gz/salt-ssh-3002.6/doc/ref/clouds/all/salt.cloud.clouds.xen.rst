=====================
salt.cloud.clouds.xen
=====================

.. automodule:: salt.cloud.clouds.xen
    :members:
