salt.beacons.smartos_vmadm module
=================================

.. automodule:: salt.beacons.smartos_vmadm
    :members:
