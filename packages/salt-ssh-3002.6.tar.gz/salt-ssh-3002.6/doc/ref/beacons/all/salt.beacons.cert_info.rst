======================
salt.beacons.cert_info
======================

.. automodule:: salt.beacons.cert_info
    :members:
