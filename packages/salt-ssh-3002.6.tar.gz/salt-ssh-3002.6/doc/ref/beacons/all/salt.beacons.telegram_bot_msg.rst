=============================
salt.beacons.telegram_bot_msg
=============================

.. automodule:: salt.beacons.telegram_bot_msg
    :members:
