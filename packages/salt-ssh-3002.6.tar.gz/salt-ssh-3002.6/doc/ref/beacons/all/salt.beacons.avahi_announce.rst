salt.beacons.avahi_announce module
====================================

.. automodule:: salt.beacons.avahi_announce
    :members:
    :undoc-members:
