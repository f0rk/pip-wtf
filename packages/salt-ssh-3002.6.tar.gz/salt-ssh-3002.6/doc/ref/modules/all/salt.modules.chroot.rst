salt.modules.chroot module
==========================

.. automodule:: salt.modules.chroot
    :members:
    :undoc-members:
