salt.modules.esxdatacenter module
=================================

.. automodule:: salt.modules.esxdatacenter
    :members:
    :undoc-members:
