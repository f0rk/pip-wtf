salt.modules.boto_s3 module
===========================

.. automodule:: salt.modules.boto_s3
    :members:
    :undoc-members:
