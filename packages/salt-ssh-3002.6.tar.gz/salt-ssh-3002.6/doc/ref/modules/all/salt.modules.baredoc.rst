salt.modules.baredoc module
===========================

.. automodule:: salt.modules.baredoc
    :members:
