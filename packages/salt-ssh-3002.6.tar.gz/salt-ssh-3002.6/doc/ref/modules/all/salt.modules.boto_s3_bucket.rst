salt.modules.boto_s3_bucket module
==================================

.. automodule:: salt.modules.boto_s3_bucket
    :members:
