salt.modules.jenkinsmod module
==============================

.. automodule:: salt.modules.jenkinsmod
    :members:
