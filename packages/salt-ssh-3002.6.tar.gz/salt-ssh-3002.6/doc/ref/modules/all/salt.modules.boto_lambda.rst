salt.modules.boto_lambda module
===============================

.. automodule:: salt.modules.boto_lambda
    :members:
