=====================
salt.modules.boto_kms
=====================

.. automodule:: salt.modules.boto_kms
    :members: