salt.modules.cimc module
========================

.. automodule:: salt.modules.cimc
    :members:
