salt.modules.libcloud_compute module
====================================

.. automodule:: salt.modules.libcloud_compute
    :members:
    :undoc-members:
