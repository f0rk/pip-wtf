===================
salt.grains.cimc
===================

.. automodule:: salt.grains.cimc
    :members:
