==========================
salt.grains.pending_reboot
==========================

.. automodule:: salt.grains.pending_reboot
    :members:
