salt.executors.splay module
===========================

.. automodule:: salt.executors.splay
    :members:

