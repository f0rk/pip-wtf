""" Double quotes singleline module docstring """
""" this is not a docstring """

def foo():
    pass
""" this is not a docstring """
