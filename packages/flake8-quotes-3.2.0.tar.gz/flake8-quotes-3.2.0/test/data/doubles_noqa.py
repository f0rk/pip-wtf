this_should_not_be_linted = "double quote string"  # noqa
