'''
Double quotes multiline module docstring
'''
'''
this is not a docstring
'''
def foo():
    pass
'''
this is not a docstring
'''
