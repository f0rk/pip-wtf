# Copyright 2019, Ryan P. Kelly.

from .impl import TemporaryFile

__version__ = "0.3"

__all__ = [
    "TemporaryFile",
]
