# Copyright 2020-2021, Ryan P. Kelly.

__version__ = "1.0"
