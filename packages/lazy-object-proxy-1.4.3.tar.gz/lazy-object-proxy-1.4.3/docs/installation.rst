============
Installation
============

At the command line::

    pip install lazy-object-proxy
