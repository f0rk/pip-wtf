"""For package documentation, see README"""

from .version import __version__, __git_hash__

from .api import load, loads
