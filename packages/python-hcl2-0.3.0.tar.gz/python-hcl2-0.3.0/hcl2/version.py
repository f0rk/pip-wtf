"""Place of record for the package version"""

__version__ = "0.3.0"
__git_hash__ = "5ac9ac317da2d7738b1a5caedc42c4d71e68a89c"
